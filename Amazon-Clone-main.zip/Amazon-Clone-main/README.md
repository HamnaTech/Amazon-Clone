# Amazon-Clone
An Amazon Clone made with Vanilla Html , CSS ,JS
